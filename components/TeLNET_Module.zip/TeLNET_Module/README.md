# TeLNET_Module
## for SCDE (Smart Connected Device Engine) V2 only !

* TeLNET -> Telnet access for SCDE! Used to write cmds or read msg from SCDE.

* Module -> intended for use with SCDE (Smart Connected Device Engine) only !

---


Created by Maik Schulze, Sandfuhren 4, 38448 Wolfsburg, Germany, for EcSUHA.de

MSchulze780@GMAIL.COM

Copyright by EcSUHA

This is part of

- ESP 8266EX & ESP32 SoC Activities ...

- HoME CoNTROL & Smart Connected Device Engine Activities ...
 
EcSUHA - ECONOMIC SURVEILLANCE AND HOME AUTOMATION - WWW.EcSUHA.DE

---
 










x
