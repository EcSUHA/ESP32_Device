#ifndef Device_WEBIFtokens_H
#define Device_WEBIFtokens_H

#include "WebIf_Module.h"



int Device_WEBIFtokens(WebIf_HTTPDConnSlotData_t *conn, char *token, void **arg);



#endif /* Device_WEBIFtokens_H */
