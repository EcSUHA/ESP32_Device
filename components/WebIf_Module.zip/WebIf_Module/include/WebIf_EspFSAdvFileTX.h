#ifndef WEBIF_ESPFSADVFILETX_H
#define WEBIF_ESPFSADVFILETX_H

#include "WebIf_Module.h"
//#include "Espfs.h"



int WebIf_EspFSAdvFileTX(WebIf_HTTPDConnSlotData_t *connData);



#endif /*WEBIF_ESPFSADVFILETX*/
