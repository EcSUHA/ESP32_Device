#ifndef _ModuleWebIF_ActiveDirectory_H_
#define _ModuleWebIF_ActiveDirectory_H_



const WebIf_ActiveResourcesDataA_t BuiltInUrlsX[];
const WebIf_ActiveResourcesDataB_t BuiltInActiveResourcesX[];



#endif /*_ModuleWebIF_ActiveDirectory_H_*/
