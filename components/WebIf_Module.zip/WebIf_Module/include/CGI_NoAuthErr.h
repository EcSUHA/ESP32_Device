#ifndef CGI_NOAUTHERR_H
#define CGI_NOAUTHERR_H

#include "WebIf_Module.h"

int NoAuthErr_cgi(WebIf_HTTPDConnSlotData_t *conn);



#endif /* CGI_NOAUTHERR_H */

