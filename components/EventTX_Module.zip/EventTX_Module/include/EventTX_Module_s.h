﻿// SCDE-Module EVENTTX_Module (IO-Device for SPI Hardware)

#ifndef EVENTTX_MODULE_S_H
#define EVENTTX_MODULE_S_H

// -------------------------------------------------------------------------------------------------

// this Module is made for the Smart-Connected-Device-Engine
#include "SCDE_s.h"

// this Module provides functions for other Modules:
#include "WebIf_Module global types.h"
//#include "WebIf_Module_s.h"

// this Module uses an 1st stage:
// -- no ---

// -------------------------------------------------------------------------------------------------










// -------------------------------------------------------------------------------------------------


/* 
 * Entry EventTX Definition (struct) stores values for operation valid only for the defined instance of an
 * loaded module. Values are initialized by SCDE an the loaded module itself.
 */
typedef struct Entry_EventTX_Definition_s {

  Entry_Definition_t common;		// ... the common part of the definition

//---

  enum espconn_type type;		// type of the espconn (TCP, UDP)
  enum espconn_state state;		// current state of the espconn
  union {
	esp_tcp *tcp;			// connection details IP,Ports, ...
	esp_udp *udp;
  } proto;
   
  espconn_recv_callback recv_callback;	// A callback function for event: receive-data

  espconn_sent_callback send_callback;	// a callback function for event: send-data

  uint8_t link_cnt;

  void* reverse;			// the reverse link to application-conn-slot-data

  int EventTX_CtrlRegA;			// EventTX Control-Reg-A (enum EventTX_CtrlRegA from WEBIF.h)

  HTTPD_InstanceCfg_t* HTTPD_InstCfg;	// link to configuration of this HTTPD-Instance
 
  uint8_t slot_no;			// slot number in this instance


  int ETXCC_State;			// SCDE Event-TX-Connect-Control State

  int SCDEETX_ConnCNT;			// STATISTICS - connections made counter
  int SCDEETX_MsgCNT;			// STATISTICS - messages sent from queue counter
  int SCDEETX_RcvOKCNT;			// STATISTICS - messages OK sent (determinated by response code)
  int SCDEETX_RcvNOKCNT;		// STATISTICS - Error counter: retrys, ... ?

} Entry_EventTX_Definition_t;



// SCDE Event-TX-Connect-Control - State (enum) Monitoring
enum ETXCC_State
  { s_idle = 0					// #000 idle state, !! no connection control !!
  , s_delay_then_idle = 8*10-1			// #079 connection control - delay idle state
  , s_dns_lookup_failed	= 80			// #080 connection control - DNS lookup failed state
  , s_monitoring_dns_lookup = 80+8*10-1		// #159 connection control - monitoring DNS lookup to get IP adress
  , s_conn_proc_IP_failed = 160			// #160 connection control - connection process to IP failed state
  , s_monitoring_conn_proc_IP = 160+8*10-1	// #239 connection control - monitoring connection process to an IP adress
};






// -------------------------------------------------------------------------------------------------





// --------------------------------------------------------------------------------------------------

//
void EventTX_Manage_Connection (Entry_EventTX_Definition_t* p_entry_eventtx_definition);

//
void EventTX_IPConnect(const char* name, ip_addr_t* ip, Entry_EventTX_Definition_t* p_entry_eventtx_definition);

// --------------------------------------------------------------------------------------------------



/*
 * typedefs of ESP32_SPI_Module Function Callbacks
 * This Fn are provided & made accessible for client modules - for operation
 */
// typedef for ESP32_SPI_Module_spi_bus_add_deviceFn - adds an device to the definitions host
//typedef strTextMultiple_t*  (*ESP32_SPI_bus_add_deviceFn_t) (ESP32_SPI_Definition_t* ESP32_SPI_Definition, const ESP32_SPI_device_interface_config_t *dev_config, ESP32_SPI_device_handle_t *handle);



/*
 * ESP32 SPI provided Fn - table
 * Stores common + custom functions this Module provides to the SCDE (and client Modules)

 */
typedef struct EventTX_ProvidedByModule_s {
// --- first the provided common module functions ---
  ProvidedByModule_t common;							// the common fn
// --- now the provided custom module fuctions ---
//  ESP32_SPI_bus_add_deviceFn_t ESP32_SPI_bus_add_deviceFn;			// adds an device to the definitions host
} EventTX_ProvidedByModule_t;



#endif /*EVENTTX_MODULE_S_H*/

