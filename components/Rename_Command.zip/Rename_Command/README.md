Help for Define Command

