#ifndef TiStCfg_cgi_H
#define TiStCfg_cgi_H

#include "WebIF_Module.h"



int TiStCfg_cgi(WebIF_HTTPDConnSlotData_t *connData);



#endif /* TiStCfg_cgi_H */
