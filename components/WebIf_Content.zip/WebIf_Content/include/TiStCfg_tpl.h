#ifndef TiStCfg_tpl_H
#define TiStCfg_tpl_H

#include "WebIF_Module.h"



void TiStCfg_tpl(WebIF_HTTPDConnSlotData_t *connData, char *token, void **arg);



#endif /* TiStCfg_tpl_H */
