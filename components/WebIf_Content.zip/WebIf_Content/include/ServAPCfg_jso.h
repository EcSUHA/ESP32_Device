#ifndef ServAPCfg_jso_H
#define ServAPCfg_jso_H

#include "WebIf_Module.h"



int ServAPCfg_jso(WebIf_HTTPDConnSlotData_t *conn) ;




#endif /* ServAPCfg_jso_H */
