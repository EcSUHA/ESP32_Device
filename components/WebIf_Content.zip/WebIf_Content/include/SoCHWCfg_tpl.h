#ifndef SoCHWCfg_tpl_H
#define SoCHWCfg_tpl_H

#include "WebIF_Module.h"



void SoCHWCfg_tpl(WebIF_HTTPDConnSlotData_t *connData, char *token, void **arg);



#endif /* SoCHWCfg_tpl_H */
