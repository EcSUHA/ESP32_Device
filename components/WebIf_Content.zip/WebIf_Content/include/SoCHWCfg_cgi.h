#ifndef SoCHWCfg_cgi_H
#define SoCHWCfg_cgi_H

#include "WebIF_Module.h"



int SoCHWCfg_cgi(WebIF_HTTPDConnSlotData_t *connData);



#endif /* SoCHWCfg_cgi_H */
