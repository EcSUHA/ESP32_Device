#ifndef ServAPCfg_cgi_H
#define ServAPCfg_cgi_H

#include "WebIf_Module.h"



int ServAPCfg_cgi(WebIf_HTTPDConnSlotData_t *connData);



#endif /* ServAPCfg_cgi_H */
